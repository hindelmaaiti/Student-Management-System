import sys
import os
import pandas as pd
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QDialog, QLabel, QLineEdit, QPushButton,
    QVBoxLayout, QHBoxLayout, QMessageBox, QTableWidget, QTableWidgetItem,
    QStackedWidget, QHeaderView, QFrame, QFormLayout, QSizePolicy
)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QIcon, QPixmap, QPainter, QColor


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_FILE = os.path.join(BASE_DIR, "..", "etudiants.csv")


ICON_PATH = r"C:\Users\Lenovo\Desktop\my_projet\esktop\static\images"

ICONS = {
    "dashboard": os.path.join(ICON_PATH, "export.png"),
    "students":  os.path.join(ICON_PATH, "list.png"),
    "stats":     os.path.join(ICON_PATH, "stats.png"),
    "logout":    os.path.join(ICON_PATH, "user.png"),
    "edit":      os.path.join(ICON_PATH, "edit.png"),
    "delete":    os.path.join(ICON_PATH, "delete.png")
}


def load_white_icon(path):
    pixmap = QPixmap(path)
    if pixmap.isNull():
        return QIcon()
    white_pixmap = QPixmap(pixmap.size())
    white_pixmap.fill(Qt.transparent)
    painter = QPainter(white_pixmap)
    painter.setCompositionMode(QPainter.CompositionMode_Source)
    painter.fillRect(white_pixmap.rect(), QColor("white"))
    painter.setCompositionMode(QPainter.CompositionMode_DestinationIn)
    painter.drawPixmap(0, 0, pixmap)
    painter.end()
    return QIcon(white_pixmap)


class DataManager:
    def __init__(self, filename):
        self.filename = filename
        if not os.path.exists(filename):
            self.data = pd.DataFrame(columns=['ID', 'Nom', 'Prénom', 'Email', 'Matière', 'Note'])
            self.data.to_csv(filename, index=False)
        else:
            self.data = pd.read_csv(filename)

    def reload(self):
        self.data = pd.read_csv(self.filename)

    def save(self):
        self.data.to_csv(self.filename, index=False)

    def ajouter_etudiant(self, nom, prenom, email, matiere, note):
        self.reload()
        new_id = 1 if self.data.empty else int(self.data['ID'].max()) + 1
        new_student = pd.DataFrame([[new_id, nom, prenom, email, matiere, note]],
                                   columns=['ID', 'Nom', 'Prénom', 'Email', 'Matière', 'Note'])
        self.data = pd.concat([self.data, new_student], ignore_index=True)
        self.save()

    def supprimer_etudiant(self, id):
        self.reload()
        self.data = self.data[self.data['ID'] != id]
        self.save()

    def modifier_etudiant(self, id, nom, prenom, email, matiere, note):
        self.reload()
        self.data.loc[self.data['ID'] == id, ['Nom', 'Prénom', 'Email', 'Matière', 'Note']] = [
            nom, prenom, email, matiere, note
        ]
        self.save()

    def obtenir_etudiants(self):
        self.reload()
        return self.data.sort_values(by='ID')

    def obtenir_statistiques(self):
        self.reload()
        if not self.data.empty:
            stats = self.data.groupby('Matière')['Note'].mean().reset_index()
            stats.columns = ['Matière', 'Moyenne']
            return stats
        else:
            return pd.DataFrame(columns=['Matière', 'Moyenne'])


data_manager = DataManager(CSV_FILE)


class ConnexionPage(QWidget):
    login_success = pyqtSignal(str)
    
    def __init__(self):
        super().__init__()
        self.initUI()
    
    def initUI(self):
        self.setStyleSheet("""
            QWidget { background-color: #ffffff; font-family: Arial, sans-serif; }
            QLabel { color: #212529; font-size: 16px; }
            QLineEdit { font-size: 14px; padding: 8px; border: 1px solid #ced4da; border-radius: 4px; }
            QPushButton { background-color: #0d6efd; color: white; font-size: 15px; border-radius: 4px; padding: 8px 16px; }
            QPushButton:hover { background-color: #0b5ed7; }
        """)
        layout = QVBoxLayout()
        title_label = QLabel("Connexion")
        title_label.setStyleSheet("font-size: 40px; font-weight: bold;")
        title_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(title_label)
        layout.addSpacing(20)
        self.username_edit = QLineEdit()
        self.username_edit.setPlaceholderText("Nom d'utilisateur")
        self.username_edit.setFixedWidth(380)
        self.username_edit.setText("hind_elmaaiti@gmail.com")
        layout.addWidget(self.username_edit, alignment=Qt.AlignCenter)
        layout.addSpacing(20)
        self.password_edit = QLineEdit()
        self.password_edit.setPlaceholderText("Mot de passe")
        self.password_edit.setEchoMode(QLineEdit.Password)
        self.password_edit.setFixedWidth(380)
        self.password_edit.setText("hind123")
        layout.addWidget(self.password_edit, alignment=Qt.AlignCenter)
        layout.addSpacing(20)
        login_button = QPushButton("Se connecter")
        login_button.clicked.connect(self.check_credentials)
        layout.addWidget(login_button, alignment=Qt.AlignCenter)
        layout.addStretch()
        self.setLayout(layout)
    
    def check_credentials(self):
        username = self.username_edit.text().strip()
        password = self.password_edit.text().strip()
        if username == "hind_elmaaiti@gmail.com" and password == "hind123":
            self.login_success.emit(username)
        else:
            QMessageBox.critical(self, "Erreur", "Nom d'utilisateur ou mot de passe incorrect !")


class LoginWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Page de Connexion")
        self.setGeometry(0, 0, 1920, 1080)
        self.initUI()
    
    def initUI(self):
        self.sidebar = QFrame()
        self.sidebar.setObjectName("sidebar")
        self.sidebar.setStyleSheet("""
            QFrame#sidebar { background-color: #0559ac; }
            QPushButton { background-color: transparent; color: white; border: none; text-align: left; font-size: 25px; padding: 12px 10px; font-family: Arial, sans-serif; }
            QPushButton:hover { background-color: #0c4176; }
        """)
        self.sidebar.setFixedWidth(220)
        sidebar_layout = QVBoxLayout()
        self.btn_connexion = QPushButton("  Connexion")
        self.btn_connexion.clicked.connect(self.show_connexion_page)
        sidebar_layout.addWidget(self.btn_connexion)
        sidebar_layout.addStretch()
        self.sidebar.setLayout(sidebar_layout)
        
        self.stack = QStackedWidget()
        self.connexion_page = ConnexionPage()
        self.stack.addWidget(self.connexion_page)
        self.connexion_page.login_success.connect(self.open_main_window)
        
        main_widget = QWidget()
        main_layout = QHBoxLayout()
        main_layout.addWidget(self.sidebar)
        main_layout.addWidget(self.stack)
        main_widget.setLayout(main_layout)
        self.setCentralWidget(main_widget)
        
        self.show_connexion_page()
    
    def show_connexion_page(self):
        self.stack.setCurrentWidget(self.connexion_page)
    
    def open_main_window(self, username):
        self.main_window = MainWindow(username)
        self.main_window.show()
        self.close()


class DashboardPage(QWidget):
    def __init__(self, username, parent_main):
        super().__init__()
        self.parent_main = parent_main
        self.username = username
        # Chemin de l'image de fond (vérifiez que le chemin est correct)
        self.bg = QPixmap("C:/Users/Lenovo/Desktop/my_projet/esktop/static/images/background.jpg")
        self.setStyleSheet("background-color: noir;")
        self.layout = QVBoxLayout()
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(0)
        self.setLayout(self.layout)
        center_widget = QWidget()
        center_widget.setStyleSheet("background: transparent;")
        center_layout = QVBoxLayout()
        center_layout.setAlignment(Qt.AlignCenter)
        center_widget.setLayout(center_layout)
        label_bienvenue = QLabel("Bienvenue")
        label_bienvenue.setStyleSheet("color: noir; font-size: 40px; font-weight: bold;")
        label_bienvenue.setAlignment(Qt.AlignCenter)
        center_layout.addWidget(label_bienvenue)
        label_username = QLabel(self.username)
        label_username.setStyleSheet("color: noir; font-size: 30px; font-weight: bold")
        label_username.setAlignment(Qt.AlignCenter)
        center_layout.addWidget(label_username)
        label_description = QLabel("Vous pouvez gérer les étudiants,\nconsulter les statistiques, etc.")
        label_description.setStyleSheet("color: noir; font-size: 20px; font-weight: bold")
        label_description.setAlignment(Qt.AlignCenter)
        center_layout.addWidget(label_description)
        btn_students = QPushButton("Voir la page Étudiants")
        btn_students.setStyleSheet("""
            background-color: #0d6efd;
            color: white;
            font-size: 18px;
            padding: 5px 6px;
            border-radius: 3px;
        """)
        btn_students.setCursor(Qt.PointingHandCursor)
        btn_students.clicked.connect(self.go_to_students)
        center_layout.addWidget(btn_students)
        self.layout.addStretch()
        self.layout.addWidget(center_widget)
        self.layout.addStretch()
    
    def go_to_students(self):
        self.parent_main.show_students()
    
    def paintEvent(self, event):
        painter = QPainter(self)
        if not self.bg.isNull():
            painter.drawPixmap(self.rect(), self.bg)
        super().paintEvent(event)

class StudentsPage(QWidget):
    def __init__(self, data_manager, parent_main):
        super().__init__()
        self.data_manager = data_manager
        self.parent_main = parent_main
        self.initUI()
    
    def initUI(self):
        layout = QVBoxLayout()
        title = QLabel("Liste des Étudiants")
        title.setStyleSheet("font-size: 24px; font-weight: bold; color: #212529;")
        layout.addWidget(title)
        self.btn_ajouter = QPushButton("Ajouter un étudiant")
        self.btn_ajouter.setStyleSheet("background-color: #0d6efd; color: white; padding: 6px; font-size: 16px; border-radius: 4px;")
        self.btn_ajouter.clicked.connect(lambda: self.parent_main.open_student_form(mode="add"))
        layout.addWidget(self.btn_ajouter, alignment=Qt.AlignRight)
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Rechercher par nom...")
        self.search_edit.textChanged.connect(self.refresh_table)
        layout.addWidget(self.search_edit)
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["Nom", "Prénom", "Email", "Matière", "Note", "Actions"])
        self.table.setStyleSheet("""
            QTableWidget { background-color: white; }
            QHeaderView::section { background-color: #0559ac; color: white; font-weight: bold; }
        """)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        layout.addWidget(self.table, stretch=1)
        self.setLayout(layout)
        self.refresh_table()
    
    def refresh_table(self):
        df = self.data_manager.obtenir_etudiants()
        search_term = self.search_edit.text().strip().lower()
        if search_term:
            df = df[df['Nom'].str.lower().str.contains(search_term, na=False)]
        students = df.to_dict(orient="records")
        self.table.setRowCount(len(students))
        for row_idx, student in enumerate(students):
            self.table.setItem(row_idx, 0, QTableWidgetItem(student["Nom"]))
            self.table.setItem(row_idx, 1, QTableWidgetItem(student["Prénom"]))
            self.table.setItem(row_idx, 2, QTableWidgetItem(student["Email"]))
            self.table.setItem(row_idx, 3, QTableWidgetItem(student["Matière"]))
            self.table.setItem(row_idx, 4, QTableWidgetItem(str(student["Note"])))
            
            actions_widget = QWidget()
            actions_layout = QHBoxLayout()
            actions_layout.setContentsMargins(0, 0, 0, 0)
            btn_edit = QPushButton("Modifier")
            btn_edit.setIcon(load_white_icon(ICONS["edit"]))
            btn_edit.setStyleSheet("background-color: orange; color: white; padding: 4px; font-size: 20px; border-radius: 20px;")
            btn_edit.clicked.connect(lambda _, sid=student["ID"]: self.parent_main.open_student_form(mode="edit", student_id=sid))
            btn_delete = QPushButton("Supprimer")
            btn_delete.setIcon(load_white_icon(ICONS["delete"]))
            btn_delete.setStyleSheet("background-color: red; color: white; padding: 4px; font-size: 20px; border-radius: 20px;")
            btn_delete.clicked.connect(lambda _, sid=student["ID"]: self.parent_main.delete_student(sid))
            
            actions_layout.addWidget(btn_edit)
            actions_layout.addWidget(btn_delete)
            actions_layout.addStretch()
            actions_widget.setLayout(actions_layout)
            self.table.setCellWidget(row_idx, 5, actions_widget)

class StatsPage(QWidget):
    def __init__(self, data_manager):
        super().__init__()
        self.data_manager = data_manager
        self.initUI()
    
    def initUI(self):
        layout = QVBoxLayout()
        title = QLabel("Statistiques")
        title.setStyleSheet("font-size: 24px; font-weight: bold; color: #212529;")
        layout.addWidget(title)
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Rechercher par matière...")
        self.search_edit.textChanged.connect(self.refresh_table)
        layout.addWidget(self.search_edit)
        self.table = QTableWidget()
        self.table.setColumnCount(2)
        self.table.setHorizontalHeaderLabels(["Matière", "Moyenne"])
        self.table.setStyleSheet("""
            QTableWidget { background-color: white; }
            QHeaderView::section { background-color: #0559ac; color: white; font-weight: bold; }
        """)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.table)
        layout.addStretch()
        self.setLayout(layout)
        self.refresh_table()
    
    def refresh_table(self):
        stats_df = self.data_manager.obtenir_statistiques()
        search_term = self.search_edit.text().strip().lower()
        if search_term:
            stats_df = stats_df[stats_df['Matière'].str.lower().str.contains(search_term, na=False)]
        stats = stats_df.to_dict(orient="records")
        self.table.setRowCount(len(stats))
        for i, stat in enumerate(stats):
            self.table.setItem(i, 0, QTableWidgetItem(stat["Matière"]))
            self.table.setItem(i, 1, QTableWidgetItem(f"{stat['Moyenne']:.2f}"))


class StudentForm(QDialog):
    def __init__(self, data_manager, mode="add", student=None):
        super().__init__()
        self.data_manager = data_manager
        self.mode = mode
        self.student = student
        self.setWindowTitle("Ajouter un étudiant" if mode=="add" else "Modifier un étudiant")
        self.initUI()
    
    def initUI(self):
        layout = QFormLayout()
        self.nom_edit = QLineEdit()
        self.prenom_edit = QLineEdit()
        self.email_edit = QLineEdit()
        self.matiere_edit = QLineEdit()
        self.note_edit = QLineEdit()
        if self.mode == "edit" and self.student:
            self.nom_edit.setText(self.student.get("Nom", ""))
            self.prenom_edit.setText(self.student.get("Prénom", ""))
            self.email_edit.setText(self.student.get("Email", ""))
            self.matiere_edit.setText(self.student.get("Matière", ""))
            self.note_edit.setText(str(self.student.get("Note", "")))
        layout.addRow("Nom :", self.nom_edit)
        layout.addRow("Prénom :", self.prenom_edit)
        layout.addRow("Email :", self.email_edit)
        layout.addRow("Matière :", self.matiere_edit)
        layout.addRow("Note :", self.note_edit)
        
        btn_save = QPushButton("Enregistrer")
        btn_save.setStyleSheet("background-color: #0d6efd; color: white; font-size: 14px; padding: 6px;")
        btn_save.clicked.connect(self.on_save)
        
        btn_cancel = QPushButton("Annuler")
        btn_cancel.setStyleSheet("background-color: #6c757d; color: white; font-size: 14px; padding: 6px;")
        btn_cancel.clicked.connect(self.reject)
        
        btn_layout = QHBoxLayout()
        btn_layout.addWidget(btn_save)
        btn_layout.addWidget(btn_cancel)
        layout.addRow(btn_layout)
        
        self.setLayout(layout)
    
    def validate_form(self):
        nom = self.nom_edit.text().strip()
        prenom = self.prenom_edit.text().strip()
        email = self.email_edit.text().strip()
        matiere = self.matiere_edit.text().strip()
        note_text = self.note_edit.text().strip()
        
        if not nom or not prenom or not email or not matiere or not note_text:
            QMessageBox.warning(self, "Erreur", "Tous les champs doivent être remplis.")
            return False
        
        try:
            note = float(note_text)
            if note < 0 or note > 20:
                QMessageBox.warning(self, "Erreur", "La note doit être comprise entre 0 et 20.")
                return False
        except ValueError:
            QMessageBox.warning(self, "Erreur", "La note doit être un nombre valide.")
            return False
        
        return True
    
    def on_save(self):
        if self.validate_form():
            self.accept()
    
    def get_data(self):
        return (self.nom_edit.text().strip(),
                self.prenom_edit.text().strip(),
                self.email_edit.text().strip(),
                self.matiere_edit.text().strip(),
                float(self.note_edit.text().strip()))


class MainWindow(QMainWindow):
    def __init__(self, username):
        super().__init__()
        self.username = username
        self.data_manager = DataManager(CSV_FILE)
        self.setWindowTitle("Gestion des Étudiants")
        self.setGeometry(0, 0, 1920, 1080)
        self.initUI()
    
    def initUI(self):
        self.sidebar = QFrame()
        self.sidebar.setObjectName("sidebar")
        self.sidebar.setStyleSheet("""
            QFrame#sidebar { background-color: #0559ac; }
            QPushButton { background-color: transparent; color: white; border: none; text-align: left; font-size: 24px; padding: 12px 10px; font-family: Arial, sans-serif; }
            QPushButton:hover { background-color: #0c4176; }
            QPushButton#toggleBtn { font-size: 18px; }
        """)
        self.sidebar.setFixedWidth(220)
        sidebar_layout = QVBoxLayout()
        self.toggleBtn = QPushButton("☰", self.sidebar)
        self.toggleBtn.setObjectName("toggleBtn")
        self.toggleBtn.setFixedSize(40, 40)
        self.toggleBtn.clicked.connect(self.toggle_sidebar)
        top_layout = QHBoxLayout()
        top_layout.addStretch()
        top_layout.addWidget(self.toggleBtn)
        sidebar_layout.addLayout(top_layout)
        self.btn_dashboard = QPushButton("  Dashboard", self.sidebar)
        self.btn_dashboard.setIcon(load_white_icon(ICONS["dashboard"]))
        self.btn_dashboard.clicked.connect(self.show_dashboard)
        self.btn_students = QPushButton("  Étudiants", self.sidebar)
        self.btn_students.setIcon(load_white_icon(ICONS["students"]))
        self.btn_students.clicked.connect(self.show_students)
        self.btn_stats = QPushButton("  Statistiques", self.sidebar)
        self.btn_stats.setIcon(load_white_icon(ICONS["stats"]))
        self.btn_stats.clicked.connect(self.show_stats)
        sidebar_layout.addWidget(self.btn_dashboard)
        sidebar_layout.addWidget(self.btn_students)
        sidebar_layout.addWidget(self.btn_stats)
        sidebar_layout.addStretch()
        self.btn_logout = QPushButton("  Déconnexion", self.sidebar)
        self.btn_logout.setIcon(load_white_icon(ICONS["logout"]))
        self.btn_logout.clicked.connect(self.logout)
        sidebar_layout.addWidget(self.btn_logout)
        self.sidebar.setLayout(sidebar_layout)
        
        self.stack = QStackedWidget()
        self.dashboard_page = DashboardPage(self.username, self)
        self.students_page = StudentsPage(self.data_manager, self)
        self.stats_page = StatsPage(self.data_manager)
        self.stack.addWidget(self.dashboard_page)
        self.stack.addWidget(self.students_page)
        self.stack.addWidget(self.stats_page)
        
        main_widget = QWidget()
        main_layout = QHBoxLayout()
        main_layout.addWidget(self.sidebar)
        main_layout.addWidget(self.stack)
        main_widget.setLayout(main_layout)
        self.setCentralWidget(main_widget)
        self.show_dashboard()
    
    def toggle_sidebar(self):
        if self.sidebar.width() == 220:
            self.sidebar.setFixedWidth(60)
            self.toggleBtn.setText("...")
        else:
            self.sidebar.setFixedWidth(220)
            self.toggleBtn.setText("☰")
    
    def show_dashboard(self):
        self.stack.setCurrentWidget(self.dashboard_page)
    
    def show_students(self):
        self.students_page.refresh_table()
        self.stack.setCurrentWidget(self.students_page)
    
    def show_stats(self):
        self.stats_page.refresh_table()
        self.stack.setCurrentWidget(self.stats_page)
    
    def open_student_form(self, mode="add", student_id=None):
        student = None
        if mode == "edit" and student_id is not None:
            df = self.data_manager.obtenir_etudiants()
            student_row = df[df['ID'] == student_id]
            if student_row.empty:
                QMessageBox.warning(self, "Erreur", "Étudiant non trouvé.")
                return
            student = student_row.iloc[0].to_dict()
        form = StudentForm(self.data_manager, mode, student)
        if form.exec_() == QDialog.Accepted:
            n, p, e, m, note = form.get_data()
            if mode == "add":
                self.data_manager.ajouter_etudiant(n, p, e, m, note)
                QMessageBox.information(self, "Succès", "Étudiant ajouté avec succès !")
            else:
                self.data_manager.modifier_etudiant(student_id, n, p, e, m, note)
                QMessageBox.information(self, "Succès", "Étudiant modifié avec succès !")
            self.show_students()
    
    def delete_student(self, student_id):
        reply = QMessageBox.question(self, "Confirmation",
                                      "Êtes-vous sûr de vouloir supprimer cet étudiant ?",
                                      QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.data_manager.supprimer_etudiant(student_id)
            QMessageBox.information(self, "Succès", "Étudiant supprimé avec succès !")
            self.show_students()
    
    def logout(self):
        self.close()
        QApplication.quit()


def main():
    app = QApplication(sys.argv)
    login_window = LoginWindow()
    login_window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
