import os
import pandas as pd
from flask import Flask, render_template, request, redirect, url_for, flash, session, send_file

app = Flask(__name__)
app.secret_key = "votre_cle_secrete"  # Clé secrète pour les sessions et flash messages

CSV_FILE = "etudiants.csv"

# ----- DataManager -----
class DataManager:
    def __init__(self, filename):
        self.filename = filename
        # Vérifie si le fichier CSV existe, sinon le crée vide
        if not os.path.exists(filename):
            self.data = pd.DataFrame(columns=['ID', 'Nom', 'Prénom', 'Email', 'Matière', 'Note'])
            self.data.to_csv(filename, index=False)
        else:
            self.data = pd.read_csv(filename)
    
    def reload(self):
        """Recharge les données du fichier CSV pour tenir compte d'éventuelles modifications externes."""
        self.data = pd.read_csv(self.filename)
    
    def save(self):
        """Sauvegarde les modifications dans le CSV."""
        self.data.to_csv(self.filename, index=False)
    
    def ajouter_etudiant(self, nom, prenom, email, matiere, note):
        """Ajoute un nouvel étudiant dans le CSV."""
        self.reload()  # Recharger pour être sûr d'avoir les données à jour
        new_id = 1 if self.data.empty else self.data['ID'].max() + 1
        new_student = pd.DataFrame([[new_id, nom, prenom, email, matiere, note]],
        columns=['ID', 'Nom', 'Prénom', 'Email', 'Matière', 'Note'])
        self.data = pd.concat([self.data, new_student], ignore_index=True)
        self.save()
    
    def supprimer_etudiant(self, id):
        """Supprime un étudiant en fonction de son ID."""
        self.reload()
        self.data = self.data[self.data['ID'] != id]
        self.save()
    
    def modifier_etudiant(self, id, nom, prenom, email, matiere, note):
        """Modifie les informations d'un étudiant existant."""
        self.reload()
        self.data.loc[self.data['ID'] == id, ['Nom', 'Prénom', 'Email', 'Matière', 'Note']] = [
            nom, prenom, email, matiere, note
        ]
        self.save()
    
    def obtenir_etudiants(self):
        """Retourne l'ensemble des étudiants, triés par ID."""
        self.reload()
        return self.data.sort_values(by='ID')
    
    def rechercher_etudiant(self, nom):
        """Recherche des étudiants par leur nom (insensible à la casse)."""
        self.reload()
        return self.data[self.data['Nom'].str.lower().str.contains(nom.lower())]
    
    def filtrer_par_note(self, note_min):
        """Filtre les étudiants dont la note est >= note_min."""
        self.reload()
        return self.data[self.data['Note'] >= note_min]
    
    def obtenir_statistiques(self):
        """Calcule la moyenne des notes par matière."""
        self.reload()
        if not self.data.empty:
            stats = self.data.groupby('Matière')['Note'].mean().reset_index()
            stats.columns = ['Matière', 'Moyenne']
            return stats
        else:
            return pd.DataFrame(columns=['Matière', 'Moyenne'])

# Instanciation du DataManager
data_manager = DataManager(CSV_FILE)

# ----- Routes -----

@app.route('/')
def home():
    # Redirige vers la page de login
    return redirect(url_for('login'))

@app.route('/login', methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get('username')
        password = request.form.get('password')
        # Vérification des identifiants (username = "hind_elmaaiti@gmail.com" et password = "hind123")
        if username == "hind_elmaaiti@gmail.com" and password == "hind123":
            session['user'] = username
            flash("Connexion réussie !", "success")
            return redirect(url_for('dashboard'))
        else:
            flash("Nom d'utilisateur ou mot de passe incorrect !", "danger")
            return render_template('login.html')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    flash("Vous avez été déconnecté.", "info")
    return redirect(url_for('login'))

# Décorateur pour restreindre l'accès aux routes protégées
def login_required(func):
    from functools import wraps
    @wraps(func)
    def wrapper(*args, **kwargs):
        if 'user' not in session:
            flash("Veuillez vous connecter d'abord.", "warning")
            return redirect(url_for('login'))
        return func(*args, **kwargs)
    return wrapper

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

@app.route('/students')
@login_required
def students():
    # Récupère les paramètres de recherche et de filtrage
    search = request.args.get('search', '')
    note_min = request.args.get('note_min', '')
    # Charge tous les étudiants (les données sont rechargées dans la méthode)
    students_data = data_manager.obtenir_etudiants()
    # Filtre par nom (si search est non vide)
    if search:
        students_data = data_manager.rechercher_etudiant(search)
    # Filtre par note minimale (si note_min est non vide)
    if note_min:
        try:
            note_min_val = float(note_min)
            students_data = data_manager.filtrer_par_note(note_min_val)
        except ValueError:
            pass  # Ignore si l'entrée est invalide
    # Convertit en dictionnaire pour l'utiliser dans le template
    students_data = students_data.to_dict(orient='records')
    return render_template('students.html', students=students_data, search=search, note_min=note_min)

@app.route('/student/add', methods=["GET", "POST"])
@login_required
def add_student():
    if request.method == "POST":
        nom = request.form.get('nom')
        prenom = request.form.get('prenom')
        email = request.form.get('email')
        matiere = request.form.get('matiere')
        note = request.form.get('note')
        try:
            note = float(note)
            data_manager.ajouter_etudiant(nom, prenom, email, matiere, note)
            flash("Étudiant ajouté avec succès !", "success")
            return redirect(url_for('students'))
        except ValueError:
            flash("La note doit être un nombre.", "danger")
    return render_template('add_student.html')

@app.route('/student/edit/<int:id>', methods=["GET", "POST"])
@login_required
def edit_student(id):
    # Récupère la ligne correspondant à l'ID (attention : ici on utilise la donnée en mémoire, mais vous pouvez aussi recharger)
    student_row = data_manager.data[data_manager.data['ID'] == id]
    if student_row.empty:
        flash("Étudiant non trouvé.", "danger")
        return redirect(url_for('students'))
    student = student_row.iloc[0].to_dict()
    if request.method == "POST":
        nom = request.form.get('nom')
        prenom = request.form.get('prenom')
        email = request.form.get('email')
        matiere = request.form.get('matiere')
        note = request.form.get('note')
        try:
            note = float(note)
            data_manager.modifier_etudiant(id, nom, prenom, email, matiere, note)
            flash("Étudiant modifié avec succès !", "success")
            return redirect(url_for('students'))
        except ValueError:
            flash("La note doit être un nombre.", "danger")
    return render_template('edit_student.html', student=student)

@app.route('/student/delete/<int:id>', methods=["POST"])
@login_required
def delete_student(id):
    data_manager.supprimer_etudiant(id)
    flash("Étudiant supprimé avec succès !", "success")
    return redirect(url_for('students'))

@app.route('/stats')
@login_required
def stats():
    # Récupère le paramètre de recherche pour la matière
    search = request.args.get('search', '')
    stats_df = data_manager.obtenir_statistiques()
    if search:
        stats_df = stats_df[stats_df['Matière'].str.contains(search, case=False, na=False)]
    stats_data = stats_df.to_dict(orient='records')
    return render_template('stats.html', stats=stats_data, search=search)

@app.route('/export')
@login_required
def export_csv():
    # Permet de télécharger le fichier CSV
    return send_file(CSV_FILE, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
